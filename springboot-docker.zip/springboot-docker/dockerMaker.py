import os
import shutil
import argparse
import yaml
import ruamel.yaml

# modify application file
def modifyApplicationProperties():
    with open("./new_demo/src/main/resources/application.properties", "r+", encoding="utf-8") as file:
        lines = file.read()
        stringFilter = 'server.port=9966'
        stringBeginPosition = lines.find(stringFilter)

        file.seek(stringBeginPosition, 0)
        file.write('server.port='+args.port+'\n')

# modify dockerfile
def modifyDockerfile():
    with open("./new_demo/src/main/docker/Dockerfile", "r+", encoding="utf-8")as file:
        lines = file.read()
        stringFilter = 'EXPOSE 9966'
        stringBeginPosition = lines.find(stringFilter)

        file.seek(stringBeginPosition, 0)
        file.write('EXPOSE '+args.port+'\n')

# modify docker-compose.yml
def modifyDockerCompose():
    data1 = {
        'version': '3',
        'services': {
            'springboot': {
                'image': args.image,
                'ports': [args.port+':'+args.port],
                'container_name': 'springboot'
            },
            'prometheus': {
                'image': 'prom/prometheus',
                'ports': ['9090:9090'],
                'volumes': ['../docker/prometheus.yml:/etc/prometheus/prometheus.yml'],
                'depends_on': ['springboot'],
                'container_name': 'prometheus'
            },
            'grafana': {
                'image': 'grafana/grafana',
                'ports': ['3030:3030'],
                'container_name': 'grafana'
            }
        }
    }

    with open("./new_demo/src/main/docker-compose/docker-compose.yml", "w", encoding="utf-8") as f:
        yaml.dump(data1, f, allow_unicode=True,
                  default_flow_style=False, sort_keys=False)

# modify prometheus.yml
def modifyPrometheus():
    data1 = {
        'scrape_configs':
            [{'job_name': 'springboot',
              'scrape_interval': '5s',
              'metrics_path': '/actuator/prometheus',
              'static_configs': [{'targets': [args.image+':'+args.port]}]
              }]
    }

    with open("./new_demo/src/main/docker/prometheus.yml", "w", encoding="utf-8") as f:
        yaml.dump(data1, f, allow_unicode=True,
                  default_flow_style=False, sort_keys=False)


if __name__ == '__main__':
    # Init parameter
    welcome = 'welcome to create a spring-boot file with prometheus.\n use $python --help'
    parser = argparse .ArgumentParser(description=welcome)

    dir = './new_demo'

    # arg parse
    parser.add_argument('-p', '--port', type=str, dest='port',
                        help='Input your server port number.\n')
    parser.add_argument('-i', '--image', type=str, dest='image',
                        help='Input your spring boot image name.\n')
    args = parser.parse_args()

    # create new file
    if not os.path.exists(dir):
        shutil.copytree('./demo', './new_demo')

    # change pom of new file
    shutil.copyfile("./lib/pom.txt", "./new_demo/pom.xml")
    shutil.copyfile("./lib/application.txt",
                    "./new_demo/src/main/resources/application.properties")
    shutil.copytree("./lib/docker", "./new_demo/src/main/docker")
    shutil.rmtree("./new_demo/src/main/java/")
    shutil.copytree("./lib/java", "./new_demo/src/main/java")

    # modify files
    modifyApplicationProperties()
    modifyDockerfile()
    modifyDockerCompose()
    modifyPrometheus()
