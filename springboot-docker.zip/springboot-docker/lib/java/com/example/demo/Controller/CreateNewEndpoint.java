package com.example.demo.Controller;

import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.web.annotation.WebEndpoint;
import org.springframework.stereotype.Component;

/*id的部分為在actuator暴露的資訊名稱*/
@Component
@WebEndpoint(id="getNameReturnAString")
public class CreateNewEndpoint{
    /*可以利用@ReadOperation、@WriteOperation、@DeleteOperation控制在網址做的動作*/
    @ReadOperation
    public String get(@Selector String name) {
        /*這裡可以加入自創的邏輯判斷然後回傳到網頁上呈現*/
        return "new Endpoint";
    }
}

