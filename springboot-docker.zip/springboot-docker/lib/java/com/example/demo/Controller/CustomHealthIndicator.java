package com.example.demo.Controller;

import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.stereotype.Component;
/*customIndicator可以替換成想在網頁上呈現的名字*/
@Component("customIndicator")
public class CustomHealthIndicator extends AbstractHealthIndicator {
    /*自創邏輯判斷*/

    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        boolean running = true;
        if (running) {
            /* withDetail的部分可以加入取得電腦資訊的java code
            java.lang.System API:https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/System.html*/
            builder.up().withDetail("status","healthy").withDetail("time",System.currentTimeMillis());
        } else {
            builder.down();
        }
    }
}
